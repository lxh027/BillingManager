<?php /*a:1:{s:71:"D:\WorkSpace\PHP\BillingManager\application\index\view\index\index.html";i:1583559481;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>订单管理系统</title>
    <meta name="description" content="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="/public/static//vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="/public/static//vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="/public/static//css/fontastic.css">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <!-- jQuery Circle-->
    <link rel="stylesheet" href="/public/static//css/grasp_mobile_progress_circle-1.0.0.min.css">
    <!-- Custom Scrollbar-->
    <link rel="stylesheet" href="/public/static//vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="/public/static//css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="/public/static//css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="/public/static//img/favicon.ico">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>
<body>
<!-- Side Navbar -->
<nav class="side-navbar">
    <div class="side-navbar-wrapper">
        <!-- Sidebar Header    -->
        <div class="sidenav-header d-flex align-items-center justify-content-center">
            <!-- User Info-->
            <div class="sidenav-header-inner text-center"><img src="/public/static//img/user.jpg" alt="person" class="img-fluid rounded-circle">
                <h2 class="h5"><?php echo htmlentities($name); ?></h2><span><?php echo htmlentities($authority); ?></span>
            </div>
            <!-- Small Brand information, appears on minimized sidebar-->
            <div class="sidenav-header-logo"><a href="/public/index.php/index/index/index" class="brand-small text-center"> <strong>B</strong><strong class="text-primary">D</strong></a></div>
        </div>
        <!-- Sidebar Navigation Menus-->
        <div class="main-menu">
            <h5 class="sidenav-heading">订单管理</h5>
            <ul id="side-main-menu" class="side-menu list-unstyled">
                <li><a href="/public/index.php/index/index/index"> <i class="icon-home"></i>主页                             </a></li>
                <li><a href="/public/index.php/index/bill/index"> <i class="icon-bill"></i>业务单列表 </a></li>
                <li><a href="/public/index.php/index/bill/add"> <i class="icon-check"></i>新建业务单 </a></li>
            </ul>
        </div>
        <div class="admin-menu">
            <h5 class="sidenav-heading">客户管理</h5>
            <ul id="side-customer-menu" class="side-menu list-unstyled">
                <li> <a href="/public/index.php/index/customer/index"> <i class="icon-user"> </i>客户列表</a></li>
                <li> <a href="/public/index.php/index/customer/add"> <i class="icon-presentation"> </i>新建客户</a></li>
            </ul>
        </div>
        <?php if($authority == "管理员"): ?>
        <div class="admin-menu">
            <h5 class="sidenav-heading">项目管理</h5>
            <ul id="side-product-menu" class="side-menu list-unstyled">
                <li> <a href="/public/index.php/index/category/index"> <i class="icon-screen"> </i>项目列表</a></li>
                <li> <a href="/public/index.php/index/category/add"> <i class="icon-padnote"> </i>添加项目/分类</a></li>
            </ul>
        </div>
        <div class="admin-menu">
            <h5 class="sidenav-heading">人员管理</h5>
            <ul id="side-user-menu" class="side-menu list-unstyled">
                <li> <a href="/public/index.php/index/user/index"> <i class="icon-form"> </i>员工列表</a></li>
                <li> <a href="/public/index.php/index/user/add"> <i class="icon-website"> </i>添加员工</a></li>
            </ul>
        </div>
        <?php endif; ?>
    </div>
</nav>

<div class="page">
    <!-- navbar-->
    <header class="header">
        <nav class="navbar">
            <div class="container-fluid">
                <div class="navbar-holder d-flex align-items-center justify-content-between">
                    <div class="navbar-header"><a id="toggle-btn" href="#" class="menu-btn"><i class="icon-bars"> </i></a><a href="/public/index.php/index/index/index" class="navbar-brand">
                        <div class="brand-text d-none d-md-inline-block"> <strong class="text-primary">订单管理系统</strong></div></a></div>
                    <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
                        <!-- Log out-->
                        <li class="nav-item"><a href="/public/index.php/index/index/logout" class="nav-link logout"> <span class="d-none d-sm-inline-block">登出</span><i class="fa fa-sign-out"></i></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- Counts Section -->
    <section class="dashboard-counts section-padding">
        <div class="container-fluid">

        </div>
    </section>

    <footer class="main-footer">
        <div class="container-fluid">

        </div>
    </footer>
</div>
<!-- JavaScript files-->
<script src="/public/static//vendor/jquery/jquery.min.js"></script>
<script src="/public/static//vendor/popper.js/umd/popper.min.js"> </script>
<script src="/public/static//vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="/public/static//js/grasp_mobile_progress_circle-1.0.0.min.js"></script>
<script src="/public/static//vendor/jquery.cookie/jquery.cookie.js"> </script>
<script src="/public/static//vendor/chart.js/Chart.min.js"></script>
<script src="/public/static//vendor/jquery-validation/jquery.validate.min.js"></script>
<script src="/public/static//vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="/public/static//js/charts-home.js"></script>
<!-- Main File-->
<script src="/public/static//js/front.js"></script>
</body>
</html>