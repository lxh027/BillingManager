<?php /*a:1:{s:70:"D:\WorkSpace\PHP\BillingManager\application\index\view\bill\index.html";i:1613792600;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>订单管理系统</title>
    <meta name="description" content="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="/public/static//vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="/public/static//vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="/public/static//css/fontastic.css">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <!-- jQuery Circle-->
    <link rel="stylesheet" href="/public/static//css/grasp_mobile_progress_circle-1.0.0.min.css">
    <!-- Custom Scrollbar-->
    <link rel="stylesheet" href="/public/static//vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="/public/static//css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="/public/static//css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="/public/static//img/favicon.ico">
    <link href="/public/static//css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">

    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>
<body>
<!-- Side Navbar -->
<nav class="side-navbar">
    <div class="side-navbar-wrapper">
        <!-- Sidebar Header    -->
        <div class="sidenav-header d-flex align-items-center justify-content-center">
            <!-- User Info-->
            <div class="sidenav-header-inner text-center"><img src="/public/static//img/user.jpg" alt="person" class="img-fluid rounded-circle">
                <h2 class="h5"><?php echo htmlentities($name); ?></h2><span><?php echo htmlentities($authority); ?></span>
            </div>
            <!-- Small Brand information, appears on minimized sidebar-->
            <div class="sidenav-header-logo"><a href="/public/index.php/index/index/index" class="brand-small text-center"> <strong>B</strong><strong class="text-primary">D</strong></a></div>
        </div>
        <!-- Sidebar Navigation Menus-->
        <div class="main-menu">
            <h5 class="sidenav-heading">订单管理</h5>
            <ul id="side-main-menu" class="side-menu list-unstyled">
                <li><a href="/public/index.php/index/index/index"> <i class="icon-home"></i>主页                             </a></li>
                <li><a href="/public/index.php/index/bill/index"> <i class="icon-bill"></i>业务单列表 </a></li>
                <li><a href="/public/index.php/index/bill/add"> <i class="icon-check"></i>新建业务单 </a></li>
            </ul>
        </div>
        <div class="admin-menu">
            <h5 class="sidenav-heading">客户管理</h5>
            <ul id="side-customer-menu" class="side-menu list-unstyled">
                <li> <a href="/public/index.php/index/customer/index"> <i class="icon-user"> </i>客户列表</a></li>
                <li> <a href="/public/index.php/index/customer/add"> <i class="icon-presentation"> </i>新建客户</a></li>
            </ul>
        </div>
        <?php if($authority == "管理员"): ?>
        <div class="admin-menu">
            <h5 class="sidenav-heading">项目管理</h5>
            <ul id="side-product-menu" class="side-menu list-unstyled">
                <li> <a href="/public/index.php/index/category/index"> <i class="icon-screen"> </i>项目列表</a></li>
                <li> <a href="/public/index.php/index/category/add"> <i class="icon-padnote"> </i>添加项目/分类</a></li>
            </ul>
        </div>
        <div class="admin-menu">
            <h5 class="sidenav-heading">人员管理</h5>
            <ul id="side-user-menu" class="side-menu list-unstyled">
                <li> <a href="/public/index.php/index/user/index"> <i class="icon-form"> </i>员工列表</a></li>
                <li> <a href="/public/index.php/index/user/add"> <i class="icon-website"> </i>添加员工</a></li>
            </ul>
        </div>
        <?php endif; ?>
    </div>
</nav>

<div class="page">
    <!-- navbar-->
    <header class="header">
        <nav class="navbar">
            <div class="container-fluid">
                <div class="navbar-holder d-flex align-items-center justify-content-between">
                    <div class="navbar-header"><a id="toggle-btn" href="#" class="menu-btn"><i class="icon-bars"> </i></a><a href="/public/index.php/index/index/index" class="navbar-brand">
                        <div class="brand-text d-none d-md-inline-block"> <strong class="text-primary">订单管理系统</strong></div></a></div>
                    <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
                        <!-- Log out-->
                        <li class="nav-item"><a href="/public/index.php/index/index/logout" class="nav-link logout"> <span class="d-none d-sm-inline-block">登出</span><i class="fa fa-sign-out"></i></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <section class="forms">
        <div class="container-fluid">
            <header>
                <h1 class="h3 display">订单列表</h1>
            </header>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header d-flex align-items-center">
                            <h4>订单信息</h4>
                        </div>
                        <div class="card-body">
                            <form >
                                <div class="form-group">
                                    <label for="customer">订货单位</label>
                                    <input type="text" id="customer" placeholder="客户" class="mr-3 mb-3 form-control">
                                </div>
                            </form>
                            <form class="form-inline">
                                <div class="form-group">
                                    <label for="clerk">业务员</label>
                                    <input id="clerk" type="text" placeholder="业务员" class="mr-3 mb-3 form-control">
                                    <label for="designer">设计</label>
                                    <input id="designer" type="text" placeholder="设计" class="mr-3 mb-3 form-control">
                                    <label for="tracker">跟单员</label>
                                    <input id="tracker" type="text" placeholder="跟单员" class="mr-3 mb-3 form-control">
                                </div>
                            </form>
                            <form class="form-inline">
                                <div>
                                    <label>订货日期:&ensp;&ensp;</label>
                                </div>
                                <div class="form-group">
                                    <label for="dtp_input2">开始时间</label>
                                    <div class="input-group date form_date" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">
                                        <input class="mr-3 mb-3 form-control" id="book_date_begin" size="16" type="text" value="1990-01-01" readonly>
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                                    </div>
                                    <input type="hidden" id="dtp_input3" value="" /><br/>

                                    <label for="dtp_input2">结束时间</label>
                                    <div class="input-group date form_date" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">
                                        <input class="mr-3 mb-3 form-control" id="book_date_end" size="16" type="text" value="2030-12-31" readonly>
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                                    </div>
                                    <input type="hidden" id="dtp_input4" value="" /><br/>
                                </div>
                            </form>
                            <form class="form-inline">
                                <div>
                                    <label>送货日期:&ensp;&ensp;</label>
                                </div>
                                <div class="form-group">
                                    <label for="dtp_input2">开始时间</label>
                                    <div class="input-group date form_date" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">
                                        <input class="mr-3 mb-3 form-control" id="deliver_date_begin" size="16" type="text" value="1990-01-01" readonly>
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                                    </div>
                                    <input type="hidden" id="dtp_input1" value="" /><br/>

                                    <label for="dtp_input2">结束时间</label>
                                    <div class="input-group date form_date" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">
                                        <input class="mr-3 mb-3 form-control" id="deliver_date_end" size="16" type="text" value="2030-12-31" readonly>
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                                    </div>
                                    <input type="hidden" id="dtp_input2" value="" /><br/>
                                </div>
                            </form>

                            <div class="form-group row">
                                <div class="col-sm-10 offset-sm-5">
                                    <button id="search" class="btn btn-primary col-md-1">搜索</button>
                                    <button id="clear" class="btn btn-primary col-md-1">清空</button>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-striped table-sm">
                                    <thead>
                                    <tr>
                                        <th>单号</th>
                                        <th>订货日期</th>
                                        <th>交货日期</th>
                                        <th>订货单位</th>
                                        <th>摘要</th>
                                        <th>金额状态</th>
                                        <th>业务员|设计|跟单员</th>
                                        <th>状态</th>
                                        <th>操作</th>
                                    </tr>
                                    </thead>
                                    <tbody id="table">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="main-footer">
        <div class="container-fluid">

        </div>
    </footer>
</div>
<!-- JavaScript files-->
<script src="/public/static//vendor/jquery/jquery.min.js"></script>
<script src="/public/static//vendor/popper.js/umd/popper.min.js"> </script>
<script src="/public/static//vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="/public/static//js/grasp_mobile_progress_circle-1.0.0.min.js"></script>
<script src="/public/static//vendor/jquery.cookie/jquery.cookie.js"> </script>
<script src="/public/static//vendor/chart.js/Chart.min.js"></script>
<script src="/public/static//vendor/jquery-validation/jquery.validate.min.js"></script>
<script src="/public/static//vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="/public/static//js/charts-home.js"></script>
<script type="text/javascript" src="/public/static//js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="/public/static//js/locales/bootstrap-datetimepicker.zh-CN.js" charset="UTF-8"></script>
<!-- Main File-->
<script src="/public/static//js/front.js"></script>
</body>
</html>

<script>
    let authority = "";
    $.ajax({
        url: "/public/index.php/index/user/getAuthority",
        type: "get",
        dataType: "json",
        data: {},
        success: function (data) {
            authority = data.data;
        }
    }) ;
    $(document).ready(function () {
       $.ajax({
           url: "/public/index.php/index/bill/getAllBill",
           type: "post",
           dataType: "json",
           data: {},
           success: function (data) {
               if (data.status == 0) {
                   const returnData = data.data;
                   const table_str_1 = "<tr><th scope=\"row\">";
                   const table_str_2 = "</th><td>";
                   const table_str_3 = "</td><td>";
                   const table_str_4 = "</td></tr>";
                   let content = "";
                   for (let i = 0; i < returnData.length; i++) {
                       const money_status = "总额："+returnData[i]['amount']+"<br>"
                                        +"优惠："+returnData[i]['favour']+"<br>"
                                        +"已收："+returnData[i]['pay']+"<br>"
                                        +"欠款："+(returnData[i]['amount']-returnData[i]['pay']-returnData[i]['favour']);
                       returnData[i]['product'] = returnData[i]['sno']+"<br>"+returnData[i]['settlement'];
                       returnData[i]['deliver_date'] = returnData[i]['deliver_date']+"<br>"+(returnData[i]['deliver_type']==0?"送货":"自提");

                       const edit_op = "<a href='edit?id="+returnData[i]['id']+"' target='_self'>编辑</a>";
                       const gather_op = "<a href='receive?id="+returnData[i]['id']+"' target='_self'>收款</a>";
                       const check_op = "<a href='check?id="+returnData[i]['id']+"' target='_self'>查看</a>";
                       const deliver_op = "<a href='deliverProduct?id="+returnData[i]['id']+"' target='_self'>送货</a>";
                       const delete_op = authority == "管理员"?"<a href='deleteBill?id="+returnData[i]['id']+"' target='_self'>删除</a>":"";
                       const status_money = returnData[i]['pay']+returnData[i]['favour']==returnData[i]['amount']?"已结清":"未结清";
                       const status_deliver = returnData[i]['deliver_status']==0?"未送货":"已送货";

                       const option = table_str_1+returnData[i]['product']
                           +table_str_2+returnData[i]['book_date']
                           +table_str_3+returnData[i]['deliver_date']
                           +table_str_3+returnData[i]['customer']
                           +table_str_3+returnData[i]['remark']
                           +table_str_3+money_status
                           +table_str_3+returnData[i]['clerk']+"|"+returnData[i]['designer']+"|"+returnData[i]['tracker']
                           +table_str_3+status_money+"<br>"+status_deliver
                           +table_str_3+edit_op+"&ensp;"+gather_op+"<br>"+check_op+"&ensp;"+deliver_op+"<br>"+delete_op+table_str_4;
                       content += option;
                   }
                   $("#table").html(content);
               } else {
                   alert(data.message);
               }
           }
       });
    });

    $("#search").click(function () {
        $.ajax({
            url: "/public/index.php/index/bill/searchBill",
            type: "post",
            dataType: "json",
            data: {
                'customer': $("#customer").val(),
                'clerk': $("#clerk").val(),
                'designer': $("#designer").val(),
                'tracker': $("#tracker").val(),
                'book_date_begin': $("#book_date_begin").val(),
                'book_date_end': $("#book_date_end").val(),
                'deliver_date_begin': $("#deliver_date_begin").val(),
                'deliver_date_end': $("#deliver_date_end").val()
            },
            success: function (data) {
                if (data.status == 0) {
                    const returnData = data.data;
                    const table_str_1 = "<tr><th scope=\"row\">";
                    const table_str_2 = "</th><td>";
                    const table_str_3 = "</td><td>";
                    const table_str_4 = "</td></tr>";
                    let content = "";
                    for (let i = 0; i < returnData.length; i++) {
                        const money_status = "总额："+returnData[i]['amount']+"<br>"
                            +"优惠："+returnData[i]['favour']+"<br>"
                            +"已收："+returnData[i]['pay']+"<br>"
                            +"欠款："+(returnData[i]['amount']-returnData[i]['pay']-returnData[i]['favour']);
                        returnData[i]['product'] = returnData[i]['product']+"<br>"+returnData[i]['settlement'];
                        returnData[i]['deliver_date'] = returnData[i]['deliver_date']+"<br>"+(returnData[i]['deliver_type']==0?"送货":"自提");

                        const edit_op = "<a href='edit?id="+returnData[i]['id']+"' target='_self'>编辑</a>";
                        const gather_op = "<a href='receive?id="+returnData[i]['id']+"' target='_self'>收款</a>";
                        const check_op = "<a href='check?id="+returnData[i]['id']+"' target='_self'>查看</a>";
                        const deliver_op = "<a href='deliverProduct?id="+returnData[i]['id']+"' target='_self'>送货</a>";
                        const delete_op = authority == "管理员"?"<a href='deleteBill?id="+returnData[i]['id']+"' target='_self'>删除</a>":"";
                        const status_money = returnData[i]['pay']+returnData[i]['favour']==returnData[i]['amount']?"已结清":"未结清";
                        const status_deliver = returnData[i]['deliver_status']==0?"未送货":"已送货";

                        const option = table_str_1+returnData[i]['product']
                            +table_str_2+returnData[i]['book_date']
                            +table_str_3+returnData[i]['deliver_date']
                            +table_str_3+returnData[i]['customer']
                            +table_str_3+returnData[i]['remark']
                            +table_str_3+money_status
                            +table_str_3+returnData[i]['clerk']+"|"+returnData[i]['designer']+"|"+returnData[i]['tracker']
                            +table_str_3+status_money+"<br>"+status_deliver
                            +table_str_3+edit_op+"&ensp;"+gather_op+"<br>"+check_op+"&ensp;"+deliver_op+"<br>"+delete_op+table_str_4;
                        content += option;
                    }
                    $("#table").html(content);
                } else {
                    alert(data.message);
                }
            }
        });
    });

    $("#clear").click(function () {
       $("#customer").val("");
       $("#clerk").val("");
       $("#designer").val("");
       $("#tracker").val("");
       $("#deliver_date_begin").val("1990-01-01");
       $("#deliver_date_end").val("2030-12-31");
       $("#book_date_end").val("2030-12-31");
       $("#book_date_begin").val("1990-01-01")
    });

    $('.form_date').datetimepicker({
        language:  'zh-CN',
        weekStart: 1,
        todayBtn:  1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 2,
        minView: 2,
        forceParse: 0
    });

</script>