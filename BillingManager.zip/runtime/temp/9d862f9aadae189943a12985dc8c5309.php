<?php /*a:1:{s:68:"D:\WorkSpace\PHP\BillingManager\application\index\view\bill\add.html";i:1613988078;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>订单管理系统</title>
    <meta name="description" content="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="/public/static//vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="/public/static//vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="/public/static//css/fontastic.css">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <!-- jQuery Circle-->
    <link rel="stylesheet" href="/public/static//css/grasp_mobile_progress_circle-1.0.0.min.css">
    <!-- Custom Scrollbar-->
    <link rel="stylesheet" href="/public/static//vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="/public/static//css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="/public/static//css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="/public/static//img/favicon.ico">
    <link href="/public/static//css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">

    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>
<body>
<!-- Side Navbar -->
<nav class="side-navbar">
    <div class="side-navbar-wrapper">
        <!-- Sidebar Header    -->
        <div class="sidenav-header d-flex align-items-center justify-content-center">
            <!-- User Info-->
            <div class="sidenav-header-inner text-center"><img src="/public/static//img/user.jpg" alt="person" class="img-fluid rounded-circle">
                <h2 class="h5"><?php echo htmlentities($name); ?></h2><span><?php echo htmlentities($authority); ?></span>
            </div>
            <!-- Small Brand information, appears on minimized sidebar-->
            <div class="sidenav-header-logo"><a href="/public/index.php/index/index/index" class="brand-small text-center"> <strong>B</strong><strong class="text-primary">D</strong></a></div>
        </div>
        <!-- Sidebar Navigation Menus-->
        <div class="main-menu">
            <h5 class="sidenav-heading">订单管理</h5>
            <ul id="side-main-menu" class="side-menu list-unstyled">
                <li><a href="/public/index.php/index/index/index"> <i class="icon-home"></i>主页                             </a></li>
                <li><a href="/public/index.php/index/bill/index"> <i class="icon-bill"></i>业务单列表 </a></li>
                <li><a href="/public/index.php/index/bill/add"> <i class="icon-check"></i>新建业务单 </a></li>
            </ul>
        </div>
        <div class="admin-menu">
            <h5 class="sidenav-heading">客户管理</h5>
            <ul id="side-customer-menu" class="side-menu list-unstyled">
                <li> <a href="/public/index.php/index/customer/index"> <i class="icon-user"> </i>客户列表</a></li>
                <li> <a href="/public/index.php/index/customer/add"> <i class="icon-presentation"> </i>新建客户</a></li>
            </ul>
        </div>
        <?php if($authority == "管理员"): ?>
        <div class="admin-menu">
            <h5 class="sidenav-heading">项目管理</h5>
            <ul id="side-product-menu" class="side-menu list-unstyled">
                <li> <a href="/public/index.php/index/category/index"> <i class="icon-screen"> </i>项目列表</a></li>
                <li> <a href="/public/index.php/index/category/add"> <i class="icon-padnote"> </i>添加项目/分类</a></li>
            </ul>
        </div>
        <div class="admin-menu">
            <h5 class="sidenav-heading">人员管理</h5>
            <ul id="side-user-menu" class="side-menu list-unstyled">
                <li> <a href="/public/index.php/index/user/index"> <i class="icon-form"> </i>员工列表</a></li>
                <li> <a href="/public/index.php/index/user/add"> <i class="icon-website"> </i>添加员工</a></li>
            </ul>
        </div>
        <?php endif; ?>
    </div>
</nav>

<div class="page">
    <!-- navbar-->
    <header class="header">
        <nav class="navbar">
            <div class="container-fluid">
                <div class="navbar-holder d-flex align-items-center justify-content-between">
                    <div class="navbar-header"><a id="toggle-btn" href="#" class="menu-btn"><i class="icon-bars"> </i></a><a href="/public/index.php/index/index/index" class="navbar-brand">
                        <div class="brand-text d-none d-md-inline-block"> <strong class="text-primary">订单管理系统</strong></div></a></div>
                    <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
                        <!-- Log out-->
                        <li class="nav-item"><a href="/public/index.php/index/index/logout" class="nav-link logout"> <span class="d-none d-sm-inline-block">登出</span><i class="fa fa-sign-out"></i></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <section class="forms">
        <div class="container-fluid">
            <header>
                <h1 class="h3">添加订单</h1>
            </header>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header d-flex align-items-center">
                            <h4>单号信息</h4>
                        </div>
                        <div class="card-body">

                            <form>
                               <!-- <div class="form-group">
                                    <label>合同号</label>
                                    <input type="text" id="contract" placeholder="合同号" class="form-control">
                                </div>-->
                                <div class="form-group">
                                    <label for="bill_type">单据类型</label>
                                    <select name="bill_type" id="bill_type" class="form-control">
                                        <option value="0">正常</option>
                                        <option value="1">返工</option>
                                        <option value="2">小样</option>
                                    </select>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <label for="bill_num">订单数量</label>
                            <input type="number" id="bill_num" min=0 max=50 placeholder="订单数量" value=0 class="form-control">
                        </div>
                    </div>
                </div>
                <div id="bill_info" class="row">

                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header d-flex align-items-center">
                            <h4>交易金额</h4>
                        </div>
                        <div class="card-body">
                            <form>
                                <div class="form-group">
                                    <label for="amount">总额</label>
                                    <input type="number" id="amount" readonly placeholder="总额" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="pre_pay">已付金额</label>
                                    <input type="number" id="pre_pay" placeholder="预付款" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="favour">优惠金额</label>
                                    <input type="number" id="favour" placeholder="优惠金额" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="settlement">支付方式</label>
                                    <select name="settlement" id="settlement" class="form-control">
                                        <option value="现金" selected>现金</option>
                                        <option value="微信">微信</option>
                                        <option value="支付宝">支付宝</option>
                                        <option value="银行卡">银行卡</option>
                                    </select>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header d-flex align-items-center">
                            <h4>客户信息</h4>
                        </div>
                        <div class="card-body">
                            <form>
                                <div class="form-group">
                                    <label for="customer">订货单位</label>
                                    <input list="customer_list" id="customer" type="text" class="form-control">
                                    <datalist id="customer_list">
                                    </datalist>
                                </div>
                                <div class="form-group">
                                    <label for="contact">联系人</label>
                                    <input type="text" id="contact" placeholder="联系人" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="number">电话</label>
                                    <input type="text" id="number" placeholder="电话号码" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="address">地址</label>
                                    <input type="text" id="address" placeholder="地址" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="deliver_type">送货方式</label>
                                    <select name="deliver_type" id="deliver_type" class="form-control">
                                        <option value="0" >送货</option>
                                        <option value="1" >自提</option>
                                    </select>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-header d-flex align-items-center">
                            <h4>人员安排</h4>
                        </div>
                        <div class="card-body">
                            <form>
                                <div class="form-group">
                                    <label for="clerk">业务员</label>
                                    <select name="clerk" id="clerk" class="form-control">
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="designer">设计员</label>
                                    <select name="designer" id="designer" class="form-control">
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="tracker">跟单员</label>
                                    <select name="tracker" id="tracker" class="form-control">
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="source">业务来源</label>
                                    <select name="source" id="source" class="form-control">
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="writer">开单员</label>
                                    <select name="writer" id="writer" class="form-control">
                                    </select>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header d-flex align-items-center">
                            <h4>送货日期</h4>
                        </div>
                        <div class="card-body">
                            <form>
                                <div class="form-group">
                                    <label for="dtp_input2">送货时间</label>
                                    <div class="input-group date form_date" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">
                                        <input class="form-control" id="deliver_date" size="16" type="text" value="" readonly>
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                                    </div>
                                    <input type="hidden" id="dtp_input2" value="" /><br/>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header d-flex align-items-center">
                            <h4>备注</h4>
                        </div>
                        <div class="card-body">
                            <form>
                                <!--<div class="form-group">
                                    <label for="remark">摘要</label>
                                    <input type="text" id="remark" placeholder="摘要" class="form-control">
                                </div>-->
                                <div class="form-group">
                                    <label for="comment">备注</label>
                                    <input type="text" id="comment" placeholder="备注" class="form-control">
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10 offset-sm-5">
                            <button id="add_bill" class="btn btn-primary col-md-1">添加</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="main-footer">
        <div class="container-fluid">

        </div>
    </footer>
</div>
<!-- JavaScript files-->
<script src="/public/static//vendor/jquery/jquery.min.js"></script>
<script src="/public/static//vendor/popper.js/umd/popper.min.js"> </script>
<script src="/public/static//vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="/public/static//js/grasp_mobile_progress_circle-1.0.0.min.js"></script>
<script src="/public/static//vendor/jquery.cookie/jquery.cookie.js"> </script>
<script src="/public/static//vendor/chart.js/Chart.min.js"></script>
<script src="/public/static//vendor/jquery-validation/jquery.validate.min.js"></script>
<script src="/public/static//vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="/public/static//js/charts-home.js"></script>
<script type="text/javascript" src="/public/static//js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="/public/static//js/locales/bootstrap-datetimepicker.zh-CN.js" charset="UTF-8"></script>

<!-- Main File-->
<script src="/public/static//js/front.js"></script>
</body>
</html>

<script>
    $(document).ready(function () {
        /*$.ajax({
            url: "/public/index.php/index/category/getAllCategory",
            type: "get",
            dataType: "json",
            data: {},
            success: function (data) {
                if (data.status == 0) {
                    const category_list = data.data;
                    for (let i = 0; i < category_list.length; i++) {
                        const option = "<option>" + category_list[i]['name'] + "</option>";
                        $("#category").append(option);
                    }
                } else {
                    alert(data.message);
                }
            }
        });*/
        $.ajax({
            url: "/public/index.php/index/customer/getCustomer",
            type: "get",
            dataType: "json",
            data: {},
            success: function (data) {
                if (data.status == 0) {
                    const customer_list = data.data;
                    for (let i = 0; i < customer_list.length; i++) {
                        const option = "<option>" + customer_list[i]['name'] + "</option>";
                        $("#customer_list").append(option);
                    }
                } else {
                    alert(data.message);
                }
            }
        });
        $.ajax({
            url: "/public/index.php/index/user/getAllEmployee",
            type: "get",
            dataType: "json",
            data: {},
            success: function (data) {
                if (data.status == 0) {
                    const customer_list = data.data;
                    for (let i = 0; i < customer_list.length; i++) {
                        const option = "<option>" + customer_list[i]['name'] + "</option>";
                        $("#clerk").append(option);
                        $("#designer").append(option);
                        $("#tracker").append(option);
                        $("#source").append(option);
                        $("#writer").append(option);
                    }
                } else {
                    alert(data.message);
                }
            }
        });
    });

    $("#customer").change(function () {
        $.ajax({
            url: "/public/index.php/index/customer/getSpecificCustomer",
            type: "get",
            dataType: "json",
            data: {
                'name': $("#customer").val()
            },
            success: function (data) {
                if (data.status == 0) {
                    const customer = data.data;
                    $("#contact").val(customer.contact);
                    $("#number").val(customer.number);
                    $("#address").val(customer.address);
                    $("#deliver_type").val(customer.deliver);
                } else {
                    alert(data.message);
                }
            }
        });
    });

    $("#amount").click(function () {
        const bill_num = $("#bill_num").val();
        let amount = 0;
        for (let i=1; i<=bill_num; i++) {
            amount += Number($("#amount"+i).val());
        }
        $("#amount").val(amount)
    });

    /*$("#category").change(function () {
        $.ajax({
            url: "/public/index.php/index/category/getProductByCategory",
            type: "get",
            dataType: "json",
            data: {
                "category": $("#category").val()
            },
            success: function (data) {
                if (data.status == 0) {
                    const product_list = data.data;
                    let option = "";
                    for (let i = 0; i < product_list.length; i++) {
                        const op = "<option value='"+product_list[i]['id']+"'>" + product_list[i]['product'] + "</option>";
                        option += op;
                    }
                    $("#product").html(option);
                } else {
                    alert(data.message);
                }
            }
        });
    });*/

    function add_bill(index) {
        const price_unit = $("#price_unit"+index).val();
        const width = $("#width"+index).val();
        const height = $("#height"+index).val();
        const rate = $("#length_unit"+index).val();
        const unit = $("#unit"+index).val();
        const product_num = $("#product_num"+index).val();
        const price = $("#price"+index).val();
        let tot_price = 0;
        function max(a, b) {
            if (a>b) return a;
            else return b;
        }
        if (price_unit == 0) {
            tot_price = (unit*product_num)*price;
        } else if (price_unit == 1) {
            tot_price = (width*height)*price*(unit*product_num);
        } else if (price_unit == 2) {
            tot_price = (max(width, height))*price*(unit*product_num);
        } else if (price_unit == 3) {
            tot_price = width*price*(unit*product_num);
        } else if (price_unit == 4) {
            tot_price = height*price*(unit*product_num);
        } else if (price_unit == 5) {
            tot_price = (width+height)*price*(unit*product_num);
        }
        $("#amount"+index).val(tot_price);
    }

    $("#add_bill").click(function () {
        let sno = '';
        $.ajax({
            url: "/public/index.php/index/bill/getSno",
            type: "post",
            dataType: "json",
            data:{},
            success: function (data) {
                sno = data.data;
            }
        }).then(() => {
            const bill_num = $("#bill_num").val();
            let items = Array(0);
            for (let i=1; i<=bill_num; i++) {
                const item = {
                    "product": $("#product"+i).val(),
                    "price_unit": $("#price_unit"+i).val(),
                    "width": $("#width"+i).val(),
                    "height": $("#height"+i).val(),
                    "length_unit": $("#length_unit"+i).val(),
                    "product_num": $("#product_num"+i).val()*$("#unit"+i).val(),
                    "price": $("#price"+i).val(),
                    "amount": $("#amount"+i).val(),
                    "remark": $("#remark"+i).val(),
                };
                items.push(item);
            }
            $.ajax({
                url: "/public/index.php/index/bill/addBill",
                type: "post",
                dataType: "json",
                data: {
                    "sno": sno,
                    "items": items,
                    //"contract": $("#contract").val(),
                    "amount"    : $("#amount").val(),
                    "bill_type": $("#bill_type").val(),
                    "pay": $("#pre_pay").val(),
                    "favour": $("#favour").val(),
                    "settlement": $("#settlement").val(),
                    "customer": $("#customer").val(),
                    "contact": $("#contact").val(),
                    "number": $("#number").val(),
                    "address": $("#address").val(),
                    "deliver_type": $("#deliver_type").val(),
                    "clerk": $("#clerk").val(),
                    "designer": $("#designer").val(),
                    "tracker": $("#tracker").val(),
                    "source": $("#source").val(),
                    "writer": $("#writer").val(),
                    "comment": $("#comment").val(),
                    "deliver_date": $("#deliver_date").val()
                },
                success: function (data) {
                    if (data.status != 0) {
                        alert(data.message)
                    } else {
                        alert("添加成功");
                        window.location.href = "/public/index.php/index/bill/check?id="+data.data;
                    }
                }
            });
        });
    });

    $("#bill_num").change(function () {
        const bill_num = $("#bill_num").val();
        let html = "";
        for (let i=1; i<=bill_num; i++) {
            const div = "<div class=\"col-lg-4\">\n" +
                "                        <div class=\"card\">\n" +
                "                            <div class=\"card-header d-flex align-items-center\">\n" +
                "                                <h4>项目"+i+"</h4>\n" +
                "                                <input type='hidden' id='id' value="+i+">\n" +
                "                            </div>\n" +
                "                            <div class=\"card-body\">\n" +
                "                                <form>\n" +
                "                                    <div class=\"form-group\">\n" +
                "                                        <label for=\"product"+i+"\">项目类型</label>\n" +
                "                                        <input type=\"text\" id=\"product"+i+"\" class=\"form-control\">\n" +
                "                                        <!--<select name=\"category\" id=\"category\" class=\"form-control\">\n" +
                "                                        </select>-->\n" +
                "                                    </div>\n" +
                "                                    <div class=\"form-group\">\n" +
                "                                        <label for=\"remark"+i+"\">摘要</label>\n" +
                "                                        <input type=\"text\" id=\"remark"+i+"\" class=\"form-control\">\n" +
                "                                        <!--<select name=\"product\" id=\"product\" class=\"form-control\">\n" +
                "                                        </select>-->\n" +
                "                                    </div>\n" +
                "                                    <div class=\"form-group\">\n" +
                "                                        <label for=\"price_unit"+i+"\">计价方式</label>\n" +
                "                                        <select name=\"price_unit\" id=\"price_unit"+i+"\" class=\"form-control\">\n" +
                "                                            <option value=0>成品</option>\n" +
                "                                            <option value=1>面积</option>\n" +
                "                                            <option value=2>长度(长边)</option>\n" +
                "                                            <option value=3>长度(宽)</option>\n" +
                "                                            <option value=4>长度(高)</option>\n" +
                "                                            <option value=5>周长</option>\n" +
                "                                        </select>\n" +
                "                                    </div>\n" +
                "                                </form>\n" +
                "                            </div>\n" +
                "                        </div>\n" +
                "                    </div>\n" +
                "                    <div class=\"col-lg-4\">\n" +
                "                        <div class=\"card\">\n" +
                "                            <div class=\"card-header d-flex align-items-center\">\n" +
                "                                <h4>项目单位信息</h4>\n" +
                "                            </div>\n" +
                "                            <div class=\"card-body\">\n" +
                "                                <form >\n" +
                "                                    <div class=\"form-group form-inline\">\n" +
                "                                        <label for=\"amount"+i+"\">宽×高</label>\n" +
                "                                        <div class=\"form-inline\">\n" +
                "                                            <input type=\"number\" id=\"width"+i+"\" placeholder=\"宽\" class=\"form-control col-md-4\">\n" +
                "                                            ×\n" +
                "                                            <input type=\"number\" id=\"height"+i+"\" placeholder=\"高\" class=\"form-control col-md-4\">\n" +
                "                                        </div>\n" +
                "\n" +
                "                                    </div>\n" +
                "                                    <div class=\"form-group\">\n" +
                "                                        <label>长度单位</label>\n" +
                "                                        <select name=\"length_unit\" id=\"length_unit"+i+"\" class=\"form-control\">\n" +
                "                                            <option value=\"1\">mm</option>\n" +
                "                                            <option value=\"10\">cm</option>\n" +
                "                                            <option value=\"100\">m</option>\n" +
                "                                        </select>\n" +
                "                                    </div>\n" +
                "                                    <div class=\"form-group\">\n" +
                "                                        <label for=\"unit"+i+"\">数量单位</label>\n" +
                "                                        <select name=\"unit\" id=\"unit"+i+"\" class=\"form-control\">\n" +
                "                                            <option value=\"1\">×1</option>\n" +
                "                                            <option value=\"5\">×5</option>\n" +
                "                                            <option value=\"10\">×10</option>\n" +
                "                                            <option value=\"20\">×20</option>\n" +
                "                                            <option value=\"50\">×50</option>\n" +
                "                                        </select>\n" +
                "                                    </div>\n" +
                "                                </form>\n" +
                "                            </div>\n" +
                "                        </div>\n" +
                "                    </div>\n" +
                "                    <div class=\"col-lg-4\">\n" +
                "                        <div class=\"card\">\n" +
                "                            <div class=\"card-header d-flex align-items-center\">\n" +
                "                                <h4>单价信息</h4>\n" +
                "                            </div>\n" +
                "                            <div class=\"card-body\">\n" +
                "                                <form>\n" +
                "                                    <div class=\"form-group\">\n" +
                "                                        <label for=\"product_num"+i+"\">数量</label>\n" +
                "                                        <input type=\"number\" id=\"product_num"+i+"\" placeholder=\"数量\" class=\"form-control\">\n" +
                "                                    </div>\n" +
                "                                    <div class=\"form-group\">\n" +
                "                                        <label for=\"price"+i+"\">单价</label>\n" +
                "                                        <input type=\"number\" id=\"price"+i+"\" placeholder=\"单价\" class=\"form-control\">\n" +
                "                                    </div>\n" +
                "                                    <div class=\"form-group\">\n" +
                "                                        <label for=\"amount"+i+"\">订单金额</label>\n" +
                "                                        <input type=\"number\" name=\"amount\" id=\"amount"+i+"\" onclick='add_bill("+i+")' readonly=\"readonly\" placeholder=\"订单金额\" class=\"form-control\">\n" +
                "                                    </div>\n" +
                "                                </form>\n" +
                "                            </div>\n" +
                "                        </div>\n" +
                "                    </div>\n";
            html += div;
        }
        $("#bill_info").html(html);
    });

    $('.form_date').datetimepicker({
        language:  'zh-CN',
        weekStart: 1,
        todayBtn:  1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 2,
        minView: 2,
        forceParse: 0
    });
</script>